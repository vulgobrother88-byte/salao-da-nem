self.addEventListener('install', function(event) {
    console.log('Service Worker instalado');
});

self.addEventListener('push', function(event) {
    const data = event.data.text();

    self.registration.showNotification('Agendamento confirmado ✅', {
        body: data,
        icon: 'https://cdn-icons-png.flaticon.com/512/1827/1827392.png'
    });
});